Crownfall Arena Sol’Rahn V2 DESIGN DRAFT — NOT FOR CODEX YET

annotated_blueprint.png: top-down layout and terrain.
heightmap_16bit.png: 1200x900 16-bit elevation values, 0..12 meters (PROVISIONAL).
heightmap_preview.png: 8-bit visual-only elevation preview.
terrain_3d_preview.png: rendered 3D elevation preview.
lane_mask.png: lane footprints.
3v3_study_region_mask.png: conceptual region; NOT final boundaries or collision.

Six camps: three in each Wilderness, one of each Mobility/Cooldown/Defense.
Major objective is in the northern Wilderness in its own clearing, NOT on any lane.

This is a design draft. The major clearing and its route separation, actual game scale, walkable slopes, objective balance, 3v3 mode gates, collision and pathfinding still require design validation. No deployment or code changes.
